# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# Copyright (C) 2014 Alec Tramell, DMA alectramell@gmail.com
# This program is free software: you can redistribute it and/or modify it 
# under the terms of the GNU General Public License version 3, as published 
# by the Free Software Foundation.
# 
# This program is distributed in the hope that it will be useful, but 
# WITHOUT ANY WARRANTY; without even the implied warranties of 
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR 
# PURPOSE.  See the GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License along 
# with this program.  If not, see <http://www.gnu.org/licenses/>.
### END LICENSE

import os
import getpass 

from locale import gettext as _

from gi.repository import Gtk, WebKit # pylint: disable=E0611
import logging
logger = logging.getLogger('europa')

from europa_lib import Window
from europa.AboutEuropaDialog import AboutEuropaDialog
from europa.PreferencesEuropaDialog import PreferencesEuropaDialog

# See europa_lib.Window.py for more details about how this class works
class EuropaWindow(Window):
    __gtype_name__ = "EuropaWindow"
    
    def finish_initializing(self, builder): # pylint: disable=E1002
        """Set up the main window"""
        super(EuropaWindow, self).finish_initializing(builder)

        self.AboutDialog = AboutEuropaDialog
        self.PreferencesDialog = PreferencesEuropaDialog

        # Code for other initialization actions should be added here.

        self.scrolledwindow1 = self.builder.get_object('scrolledwindow1')
        self.homebutton = self.builder.get_object('homebutton')
        self.exitbutton = self.builder.get_object('exitbutton')
        self.skypebutton = self.builder.get_object('skypebutton')
        self.entry1 = self.builder.get_object('entry1')

        self.user = str(getpass.getuser())

        self.webview = WebKit.WebView()

        self.scrolledwindow1.add(self.webview)
        self.webview.show()

        self.home = str('/usr/share/europa/media/europa.fetch/index.html')

        self.webview.open('/usr/share/europa/media/europa.fetch/index.html')

    def on_homebutton_clicked(self, widget):
        self.webview.open(self.home)

    def on_skypebutton_clicked(self, widget):
        os.system('clear')
        os.system('skype &')

    def on_entry1_activate(self, widget):
        os.system('clear')
        skuser = self.entry1.get_text()
        os.system('skype skype:' + skuser + '?chat &')       

    def on_exitbutton_clicked(self, widget):
        exit()

    def on_updatebutton_clicked(self, widget):
        os.system('clear')
        os.system('cd ~/ && git clone http://github.com/europa.git &')
        os.system('gnome-terminal -x sh -x "sudo dpkg -i ~/europa/europa_0.1_all.deb"')
        os.system('clear')
        self.restart = str('/usr/share/europa/media/europa.fetch/update.html')
        self.webview.open(self.restart)
        os.system('clear')






